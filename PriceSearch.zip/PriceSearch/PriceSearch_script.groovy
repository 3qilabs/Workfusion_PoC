enableTypeOnScreen();


openExcel("${excel_file}");    
                sleep(100);

        product = getCell("${excel_file}", "A2");

            
        products = new com.workfusion.studio.rpa.recorder.api.groovy.RecorderList(getColumn("${excel_file}", ExcelColumnRowPosition.FIRST));

            
        setActiveCell("${excel_file}", "B1")



def i0 = products
if (products instanceof com.workfusion.studio.rpa.recorder.api.groovy.RecorderTable) {
    i0 = products.getRows()
}

new com.workfusion.studio.rpa.recorder.api.groovy.FilterExpression("2-100").applyTo(i0).forEach( { item ->
            sleep(100);
	timeouts().pageLoadTimeout(25000, java.util.concurrent.TimeUnit.MILLISECONDS);

    openFirefox("https://www.walmart.com/");


		$(byXpath("//*[@id=\"global-search-input\"]")).setValue(String.valueOf(item));

        sendKeys("{ENTER}");
    sleep(10000);


        if (price instanceof String) {
            price = $(byXpath("//span[@class=\"Price-characteristic\"]")).text();
        } else if (price instanceof BigDecimal) {
            price = new BigDecimal($(byXpath("//span[@class=\"Price-characteristic\"]")).text());
        } else if (price instanceof com.workfusion.studio.rpa.recorder.api.groovy.RecorderList) {
            price = new com.workfusion.studio.rpa.recorder.api.groovy.RecorderList($$(byXpath("//span[@class=\"Price-characteristic\"]")).stream().map({ e -> e.text() }).collect(java.util.stream.Collectors.toList()));
        }

        

openExcel("${excel_file}");    
                sleep(500);


        setCell("${excel_file}", ExcelCellPosition.CELL_BELOW, "${price}");


saveExcel("${excel_file}");
});


// openExcel("${excel_file}");
            
// setActiveCell("${excel_file}", "C1")

// saveExcel("${excel_file}");
// def i1 = products
// if (products instanceof com.workfusion.studio.rpa.recorder.api.groovy.RecorderTable) {
// i1 = products.getRows()
// }

// new com.workfusion.studio.rpa.recorder.api.groovy.FilterExpression("2-100").applyTo(i1).forEach( { item ->
        // sleep(100);
// timeouts().pageLoadTimeout(25000, java.util.concurrent.TimeUnit.MILLISECONDS);

// openFirefox("https://www.target.com/");

// $(byXpath("//input[@id=\"search\"]")).setValue(String.valueOf(item));
// sendKeys("{ENTER}");// sleep(10000);


// if (price instanceof String) {
// price = $(byXpath("//*[@id=\"slp\"]/section/div/div/ul/li[1]/div[1]/div[2]/div[1]/span")).text();
// } else if (price instanceof BigDecimal) {
// price = new BigDecimal($(byXpath("//*[@id=\"slp\"]/section/div/div/ul/li[1]/div[1]/div[2]/div[1]/span")).text());
// } else if (price instanceof com.workfusion.studio.rpa.recorder.api.groovy.RecorderList) {
// price = new com.workfusion.studio.rpa.recorder.api.groovy.RecorderList($$(byXpath("//*[@id=\"slp\"]/section/div/div/ul/li[1]/div[1]/div[2]/div[1]/span")).stream().map({ e -> e.text() }).collect(java.util.stream.Collectors.toList()));
// }
        

// openExcel("${excel_file}");
            // sleep(500);


// setCell("${excel_file}", ExcelCellPosition.CELL_BELOW, "${price}");

// saveExcel("${excel_file}");
// });


openExcel("${excel_file}");    
            
        setActiveCell("${excel_file}", "D1")


saveExcel("${excel_file}");
def i2 = products
if (products instanceof com.workfusion.studio.rpa.recorder.api.groovy.RecorderTable) {
    i2 = products.getRows()
}

new com.workfusion.studio.rpa.recorder.api.groovy.FilterExpression("2-100").applyTo(i2).forEach( { item ->
            sleep(100);
	timeouts().pageLoadTimeout(65000, java.util.concurrent.TimeUnit.MILLISECONDS);

    openFirefox("https://www.newegg.com/");


		$(byXpath("//*[@id=\"haQuickSearchBox\"]")).setValue(String.valueOf(item));

        sendKeys("{ENTER}");
try {
        sleep(10000);


        if (price instanceof String) {
            price = $(byXpath("//*[@id=\"bodyArea\"]/section/div/div/div[2]/div/div/div/div[2]/div[1]/div[2]/div[2]/div[1]/div/div[2]/ul/li[3]/strong")).text();
        } else if (price instanceof BigDecimal) {
            price = new BigDecimal($(byXpath("//*[@id=\"bodyArea\"]/section/div/div/div[2]/div/div/div/div[2]/div[1]/div[2]/div[2]/div[1]/div/div[2]/ul/li[3]/strong")).text());
        } else if (price instanceof com.workfusion.studio.rpa.recorder.api.groovy.RecorderList) {
            price = new com.workfusion.studio.rpa.recorder.api.groovy.RecorderList($$(byXpath("//*[@id=\"bodyArea\"]/section/div/div/div[2]/div/div/div/div[2]/div[1]/div[2]/div[2]/div[1]/div/div[2]/ul/li[3]/strong")).stream().map({ e -> e.text() }).collect(java.util.stream.Collectors.toList()));
        }

} catch (Exception i3) {
        sleep(10000);


        if (price instanceof String) {
            price = $(byXpath("//*[@id=\"bodyArea\"]/section/div/div/div[2]/div/div/div/div[2]/div[1]/div[2]/div[2]/div[1]/div/div[2]/ul/li[1]")).text();
        } else if (price instanceof BigDecimal) {
            price = new BigDecimal($(byXpath("//*[@id=\"bodyArea\"]/section/div/div/div[2]/div/div/div/div[2]/div[1]/div[2]/div[2]/div[1]/div/div[2]/ul/li[1]")).text());
        } else if (price instanceof com.workfusion.studio.rpa.recorder.api.groovy.RecorderList) {
            price = new com.workfusion.studio.rpa.recorder.api.groovy.RecorderList($$(byXpath("//*[@id=\"bodyArea\"]/section/div/div/div[2]/div/div/div/div[2]/div[1]/div[2]/div[2]/div[1]/div/div[2]/ul/li[1]")).stream().map({ e -> e.text() }).collect(java.util.stream.Collectors.toList()));
        }

}
        

openExcel("${excel_file}");    
                sleep(500);


        setCell("${excel_file}", ExcelCellPosition.CELL_BELOW, "${price}");


saveExcel("${excel_file}");
});


// openExcel("${excel_file}");
            
// setActiveCell("${excel_file}", "E1")

// saveExcel("${excel_file}");
// def i4 = products
// if (products instanceof com.workfusion.studio.rpa.recorder.api.groovy.RecorderTable) {
// i4 = products.getRows()
// }

// new com.workfusion.studio.rpa.recorder.api.groovy.FilterExpression("2-100").applyTo(i4).forEach( { item ->
        // timeouts().pageLoadTimeout(65000, java.util.concurrent.TimeUnit.MILLISECONDS);

// openFirefox("https://www.bestbuy.com/");
        // sleep(100);
// timeouts().pageLoadTimeout(65000, java.util.concurrent.TimeUnit.MILLISECONDS);

// openFirefox("https://www.bestbuy.com/");

// $(byXpath("//*[@id=\"gh-search-input\"]")).setValue(String.valueOf(item));
// sendKeys("{ENTER}");// try {
    // sleep(10000);


// if (price instanceof String) {
// price = $(byXpath("//*[@id=\"resultsTabPanel\"]/div[2]/div/div/div[3]/div/div[1]/div[2]/div[2]/div/div/div[2]/span")).text();
// } else if (price instanceof BigDecimal) {
// price = new BigDecimal($(byXpath("//*[@id=\"resultsTabPanel\"]/div[2]/div/div/div[3]/div/div[1]/div[2]/div[2]/div/div/div[2]/span")).text());
// } else if (price instanceof com.workfusion.studio.rpa.recorder.api.groovy.RecorderList) {
// price = new com.workfusion.studio.rpa.recorder.api.groovy.RecorderList($$(byXpath("//*[@id=\"resultsTabPanel\"]/div[2]/div/div/div[3]/div/div[1]/div[2]/div[2]/div/div/div[2]/span")).stream().map({ e -> e.text() }).collect(java.util.stream.Collectors.toList()));
// }
// } catch (Exception i5) {
    
// }
        

// openExcel("${excel_file}");
            // sleep(500);


// setCell("${excel_file}", ExcelCellPosition.CELL_BELOW, "${price}");

// saveExcel("${excel_file}");
// });

// sendKeys("{LWINDOWN}r{LWINUP}");


// window(new com.workfusion.studio.rpa.recorder.api.groovy.WindowDescriptor("#32770", "Run", false, false).toString(), 10000);
// sendKeys("outlook");// sleep(1700);

// sendKeys("{TAB}");// sleep(700);

// sendKeys("{ENTER}");
// sleep(5000);


// window(new com.workfusion.studio.rpa.recorder.api.groovy.WindowDescriptor("rctrl_renwnd32", "Inbox - konstantin@3qilabs.com - Outlook", false, false).toString(), 10000);// sleep(2000);


// mouse().click($(byImage("1506550639585-anchor.apng", Integer.valueOf(0), Integer.valueOf(0))).getCoordinates());
// sleep(1100);


// window(new com.workfusion.studio.rpa.recorder.api.groovy.WindowDescriptor("rctrl_renwnd32", "Untitled - Message (HTML) ", false, false).toString(), 10000);// sleep(2400);

// $(byImage("1506549828653-anchor.apng", Integer.valueOf(0), Integer.valueOf(0))).hover();// sleep(1100);

// sendKeys("konstantin@3qilabs.com");// sleep(5200);


// mouse().click($(byImage("1506549839077-anchor.apng", Integer.valueOf(0), Integer.valueOf(0))).getCoordinates());


// window(new com.workfusion.studio.rpa.recorder.api.groovy.WindowDescriptor("#32770", "Insert File", false, false).toString(), 10000);// if (excel_file_path instanceof com.workfusion.studio.rpa.recorder.api.groovy.RecorderList) {
// setClipboardText(com.workfusion.studio.rpa.recorder.api.groovy.StringTransformations.escapeDollarSign(com.workfusion.studio.rpa.recorder.utils.DelimitedConverterUtils.listToString(excel_file_path, "", "")));

// } else if (excel_file_path instanceof com.workfusion.studio.rpa.recorder.api.groovy.RecorderTable) {
// setClipboardText(com.workfusion.studio.rpa.recorder.api.groovy.StringTransformations.escapeDollarSign(com.workfusion.studio.rpa.recorder.utils.DelimitedConverterUtils.tableToString(excel_file_path, "", "", "")));

// } else if (excel_file_path instanceof BigDecimal) {
// setClipboardText(excel_file_path.toPlainString());

// } else if (excel_file_path instanceof Date) {
// setClipboardText(java.text.DateFormat.getInstance().format(excel_file_path));

// } else {
// setClipboardText(com.workfusion.studio.rpa.recorder.api.groovy.StringTransformations.escapeDollarSign(String.valueOf(excel_file_path)));
// }// sleep(6300);


// mouse().click($(byImage("1506550373959-anchor.apng", Integer.valueOf(-180), Integer.valueOf(-2))).getCoordinates());
// sendKeys("{CTRLDOWN}v{CTRLUP}");// sleep(7900);

// sendKeys("{ENTER}");// sleep(1400);

// $(byImage("1506550383855-anchor.apng", Integer.valueOf(0), Integer.valueOf(0))).hover();// sleep(1900);


// $(byImage("1506550385695-anchor.apng", Integer.valueOf(0), Integer.valueOf(0))).doubleClick();


// window(new com.workfusion.studio.rpa.recorder.api.groovy.WindowDescriptor("rctrl_renwnd32", "Untitled - Message (HTML) ", false, false).toString(), 10000);// sleep(2300);


// mouse().click($(byImage("1506549899469-anchor.apng", Integer.valueOf(0), Integer.valueOf(0))).getCoordinates());// sleep(1900);

// sendKeys("Prices for today");// sleep(1000);


// mouse().click($(byImage("1506549908853-anchor.apng", Integer.valueOf(-53), Integer.valueOf(0))).getCoordinates());// sleep(10000);
// close();
